"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { FileText, Users, Settings, Menu, X, LayoutDashboard } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

const menuItems = [
  { icon: LayoutDashboard, label: "Overview", href: "/dashboard" },
  { icon: FileText, label: "Projects", href: "/dashboard/projects" },
  { icon: Users, label: "Team", href: "/dashboard/team" },
  { icon: Settings, label: "Settings", href: "/dashboard/settings" },
]

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const pathname = usePathname()

  return (
    <div className="flex h-screen bg-gray-100">
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.aside initial={{ x: -300 }} animate={{ x: 0 }} exit={{ x: -300 }} className="w-64 bg-white shadow-xl">
            <div className="p-4 flex justify-between items-center">
              <h2 className="text-2xl font-semibold text-gray-800">Dashboard</h2>
              <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden">
                <X size={24} />
              </button>
            </div>
            <nav className="mt-6">
              {menuItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <span
                    className={`flex items-center px-4 py-3 text-gray-600 hover:bg-gray-200 transition-colors ${
                      pathname === item.href ? "bg-blue-100 text-blue-600" : ""
                    }`}
                  >
                    <item.icon className="mr-3" size={20} />
                    {item.label}
                  </span>
                </Link>
              ))}
            </nav>
          </motion.aside>
        )}
      </AnimatePresence>
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-sm">
          <div className="flex items-center justify-between p-4">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="text-gray-600 focus:outline-none">
              <Menu size={24} />
            </button>
            <div className="flex items-center space-x-4">
              <span className="text-gray-700">John Doe</span>
              <img className="h-8 w-8 rounded-full" src="https://via.placeholder.com/40" alt="User avatar" />
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100">{children}</main>
      </div>
    </div>
  )
}

